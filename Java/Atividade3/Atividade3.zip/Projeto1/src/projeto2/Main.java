
package projeto2;

public class Main {
    
    public static void main(String[] args){
        
        // numeros aleatorios
        int ale = (int) (5 + Math.random() * (10-5));
        System.out.println(ale);
    }
}

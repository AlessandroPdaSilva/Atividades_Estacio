
package exercicio_estacio;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args){
        
        Scanner scan = new Scanner(System.in);
        
        double[] arr= new double[3];
        double valor = 0;
        int i = 0;
    
        for(i = 0; i < arr.length; i++){
            System.out.println("Digite o "+(i + 1) +" numero");
            arr[i] = scan.nextInt();
            
            valor = valor + arr[i];
        }
    
        double media = valor / i;
        System.out.println("A media e "+ media);
    
    
    }
}


package joptionpane_estacio;

import javax.swing.JOptionPane;

public class Main {
    
    public static void main(String[] args){
        
        String nome = JOptionPane.showInputDialog(null," Digite o seu nome");
        JOptionPane.showMessageDialog(null,"Ola, "+nome);
        
        
        
    }
}

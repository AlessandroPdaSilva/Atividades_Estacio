 
package beans;
 
public class Calculo {
    
    public int calc(int n){
        return n * 10;
    }
    
}

package exerciciosestacio;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;

public class main {

    public static void main(String[] args) {
        // var
        ArrayList<BlocoDeNotas> blocos = new ArrayList<>();
        
        String msg="";
        int e = 0;
        
        
        
        // loop
        while (true) {
            
            // escolha
            String n = JOptionPane.showInputDialog(null, "------- BLOCO DE NOTAS ------- \n"
                    + "Escolha entre as opçoes abaixo:\n"
                    + "1 - Criar Bloco de Notas\n"
                    + "2 - Ver Bloco de notas\n"
                    + "3 - Editar Bloco de Notas\n"
                    + "4 - Excluir Bloco de Notas\n"
                    + "5 - Fechar Progama \n");

            e = Integer.parseInt(n);
            
            //
            switch (e) {
                
                case 1:// create
                    BlocoDeNotas blocoNota = new BlocoDeNotas();
                    blocoNota.setTitulo(JOptionPane.showInputDialog(null, "Digite um Titulo para o Bloco de Notas")); 
                    blocoNota.setTexto(JOptionPane.showInputDialog(null, "Digite seu Bloco de Notas")); 
                    
                    blocos.add(blocoNota);
                    JOptionPane.showMessageDialog(null, "Criado com sucesso");
                    
                    break;
                    
                    
                case 2://read
                    msg = "";
                    for(BlocoDeNotas value:blocos){        
                        msg+= value.getTitulo()+"\n"+ value.getTexto() +"\n-------------------\n";
                    }
                    
                    JOptionPane.showMessageDialog(null,msg);
                    
                    break;
                    
                    
                case 3://update
                    msg = "";
                    int j = 0;
                    
                    for(BlocoDeNotas value:blocos){        
                        msg+= "Bloco: "+j+"\n"+value.getTitulo()+"\n"+ value.getTexto() +"\n-------------------\n";
                        ++j;
                    }
                    
                    int e2 = Integer.parseInt(JOptionPane.showInputDialog(null,msg+"Escolha um bloco para EDITAR:\n(Digite o numero do Bloco ou -1 para Sair)"));
                    
                        if(e2 == -1){
                            break;
                        }
                        
                    String vTitulo = JOptionPane.showInputDialog(null, "Digite o novo Titulo para o Bloco de Notas");
                    String vTexto = JOptionPane.showInputDialog(null, "Digite o novo Texto para o Bloco de Notas");
                    blocos.get(e2).setTitulo(vTitulo);
                    blocos.get(e2).setTexto(vTexto);
                    
                    JOptionPane.showMessageDialog(null, "Editar com sucesso");
                    break;
                    
                    
                case 4://delete
                    msg = "";
                    int i = 0;
                    
                    for(BlocoDeNotas value:blocos){        
                        msg+= "Bloco: "+i+"\n"+value.getTitulo()+"\n"+ value.getTexto() +"\n-------------------\n";
                        ++i;
                    }
                    
                    int e3 = Integer.parseInt(JOptionPane.showInputDialog(null,msg+"Escolha um bloco para EXCLUIR:\n(Digite o numero do Bloco ou -1 para Sair)"));
                    
                    if(e3 == -1){
                        break;
                    }
                    blocos.remove(e3);
                    
                    JOptionPane.showMessageDialog(null, "Deletado com sucesso");
                    break;
                    
                case 5:// exit
                    System.exit(0);
                    break;
                    
                    
                default:// erro
                    JOptionPane.showMessageDialog(null, "Escolha Invalida");
                    break;
            }
            
           

        }
    }

}

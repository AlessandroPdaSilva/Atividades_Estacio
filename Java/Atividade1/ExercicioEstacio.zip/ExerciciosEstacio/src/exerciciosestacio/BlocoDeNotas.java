
package exerciciosestacio;
 
public class BlocoDeNotas {
    // var
    private String titulo;
    private String texto;
    
    // contrutor
    BlocoDeNotas(){
        setTitulo("Titulo vazio");
        setTexto("Texto Vazio");
    }
    
    // get e set
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    @Override
    public String toString() {
        return "BlocoDeNotas{" + "titulo=" + titulo + ", texto=" + texto + '}';
    }
    
    
}
